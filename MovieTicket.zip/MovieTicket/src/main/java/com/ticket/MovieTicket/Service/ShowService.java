package com.ticket.MovieTicket.Service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ticket.MovieTicket.Dao.ShowDao;
import com.ticket.MovieTicket.Dao.TheaterDao;
import com.ticket.MovieTicket.dto.TheaterDto;
import com.ticket.MovieTicket.model.Show;
import com.ticket.MovieTicket.model.Theater;

@Service
public class ShowService {
	@Autowired
	ShowDao showDao;
	@Autowired
	TheaterDao theaterDao;
	ModelMapper mappMoiver = new ModelMapper();

	// method for movie shows available in theater
	public String showTime(Show show) {
		show.setTheaterId(show.getTheaterId());
		show.setShowId(show.getShowId());
		show.setMrngShow(show.getMrngShow());
		show.setNoonShow(show.getNoonShow());
		show.setNoonShow(show.getEvngShow());
		show.setDate(show.getDate());
		showDao.save(show);
		return "show details added";
	}

	// getting list of theaters by using moviename
	public List<TheaterDto> getMovieTime(String movieName) {
		List<TheaterDto> list = new ArrayList<TheaterDto>();

		Iterable<Theater> theater = theaterDao.findAll();
		List<Show> movieList = showDao.getMovieTime(movieName);
		List<TheaterDto> theaterDto = new ArrayList<TheaterDto>();
		Iterator<Show> itrMovie = movieList.iterator();
		List<Theater> theater1 = new ArrayList<Theater>();
		Theater theater2 = new Theater();

		while (itrMovie.hasNext()) {
			TheaterDto theaterdto = new TheaterDto();

			Show show = itrMovie.next();
			theater2 = theaterDao.findById(show.getTheaterId()).orElse(null);
			theaterdto.setTheaterName(theater2.getTheaterName());
			theaterdto.setTheaterId(theater2.getTheaterId());
			theaterdto.setTheaterName(theater2.getTheaterName());
			theaterdto.setPlace(theater2.getPlace());
			theaterdto.setDate(show.getDate());
			theaterdto.setShowId(show.getShowId());
			theaterdto.setMrngShow(show.getMrngShow());
			theaterdto.setNoonShow(show.getNoonShow());
			theaterdto.setEvngShow(show.getEvngShow());
			list.add(theaterdto);
		}
		return list;

	}

}
