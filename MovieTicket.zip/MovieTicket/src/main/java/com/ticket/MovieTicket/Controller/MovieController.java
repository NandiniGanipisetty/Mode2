package com.ticket.MovieTicket.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.ticket.MovieTicket.Service.MovieService;
import com.ticket.MovieTicket.dto.TheaterDto;
import com.ticket.MovieTicket.model.Movie;

@RestController
public class MovieController {
	@Autowired
	MovieService movieService;

	@PostMapping("/add/movie")
	public String addMovie(@RequestBody Movie movie) {

		return movieService.addMovie(movie);
	}

	@GetMapping(value = "add/get/movie")
	public String findShowByMovieName(@RequestParam("movieName") String movieName, @RequestParam("date") String date) {

		return movieService.findShowByMovieName(movieName, date);

	}
}