package com.ticket.MovieTicket.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "showmovie")
public class Show {
	private String theaterId;
	@Id
	private String showId;
	private String mrngShow;
	private String noonShow;
	private String evngShow;
	private LocalDate date;

	public String getMrngShow() {
		return mrngShow;
	}

	public void setMrngShow(String mrngShow) {
		this.mrngShow = mrngShow;
	}

	public String getNoonShow() {
		return noonShow;
	}

	public void setNoonShow(String noonShow) {
		this.noonShow = noonShow;
	}

	public String getEvngShow() {
		return evngShow;
	}

	public String getTheaterId() {
		return theaterId;
	}

	public void setTheaterId(String theaterId) {
		this.theaterId = theaterId;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public String getShowId() {
		return showId;
	}

	public void setShowId(String showId) {
		this.showId = showId;
	}

}
