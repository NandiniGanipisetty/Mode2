package com.bank;

public interface Bank {
	void takeLoan(int b);
	void repayLoan(int a);
	void display(int d);
	void deposit(int e);
	void withdraw(int f);
	

}
