package com.bank;
class  SavingAccount1 implements Bank
{
	public void deposit(int a) {
		System.out.println("money deposited" +a);
	}
	@Override
	public void display(int b) {
		System.out.println("displaying balance"+b);
	}
	@Override
	public void withdraw(int c) {
		System.out.println("money withdrawal"+c);	
	}
	@Override
	public void takeLoan(int d) {
		// TODO Auto-generated method stub
		System.out.println("money withdrawal"+d);
		
	}
	@Override
	public void repayLoan(int e) {
		System.out.println("money withdrawal"+e);
		
	}

}

