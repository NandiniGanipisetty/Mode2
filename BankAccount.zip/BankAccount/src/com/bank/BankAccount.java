package com.bank;
import java.util.Scanner;
class BankAccount 
{
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("1.Deposit\n 2.withdraw\n3.display\n4.takeLoan\n5.repayLoan");
		System.out.println("enter the opertaion to be performed");
		String s=sc.next();
		int camount=10000;
		int amount;
		switch(s)
		{
		case "savings":
			Bank a=new SavingAccount1();
			amount=sc.nextInt();
			a.display(amount);
			a.deposit(amount);
			a.withdraw(amount);
			break;
		case "loan":
			Bank l=new SavingAccount1();
			amount=sc.nextInt();
			l.takeLoan(amount);
			l.repayLoan(amount);
			break;
			
			}

	}
}
