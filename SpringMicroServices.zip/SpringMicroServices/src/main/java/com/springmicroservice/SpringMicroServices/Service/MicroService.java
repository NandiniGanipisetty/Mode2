package com.springmicroservice.SpringMicroServices.Service;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.springmicroservice.SpringMicroServices.Dto.TheaterDto;

@Service
public class MicroService {
	//getting list of theaters
	public List<TheaterDto> suggestUser() {
			RestTemplate restTemplate=new RestTemplate();
	List<TheaterDto> theaterdto=	restTemplate.getForObject("http://localhost:8092/add/theater/getAll", List.class);
	

			return theaterdto;
	}
}
