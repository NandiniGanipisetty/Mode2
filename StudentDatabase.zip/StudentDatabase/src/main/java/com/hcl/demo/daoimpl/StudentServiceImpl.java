package com.hcl.demo.daoimpl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.hcl.demo.dao.StudentDAO;
import com.hcl.demo.dao.StudentService;
import com.hcl.demo.dto.StudAcademicDto;
import com.hcl.demo.model.Academic;
import com.hcl.demo.model.Student;


public class StudentServiceImpl implements StudentService {

	@Autowired
	StudentDAO studDAO;

	@Override
	public void addStudent(Student student, Academic academic) {
		studDAO.addStudent(student,academic);

	}

	@Override
	public String getDetails(String usn) {

		return studDAO.getDetails(usn);
	}

	@Override
	public List<Student> studentList() {
		// TODO Auto-generated method stub
		return studDAO.studentList();
	}

	@Override
	public List<Student> studentAge() {
		// TODO Auto-generated method stub
		return studDAO.studentAge();
	}

	@Override
	public List<Student> listStudent(int pageno, int pagesize) {
		// TODO Auto-generated method stub
		return studDAO.listStudent(pageno, pagesize);
	}
}
