package com.hcl.demo.daoimpl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.hcl.demo.dao.StudentDAO;
import com.hcl.demo.model.Academic;
import com.hcl.demo.model.College;
import com.hcl.demo.model.Student;

public class StudentDAOImpl implements StudentDAO {

	@Autowired
	SessionFactory sessionFactory;

	private static final Logger logger = LoggerFactory.getLogger(StudentDAOImpl.class);

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	ModelMapper mapper = new ModelMapper();
	//adding student details
	@Transactional
	@Override
	public void addStudent(Student student, Academic academic) {
		Session session = this.sessionFactory.getCurrentSession();

		logger.info("Saving details from registration.jsp form to db of Student and Academic table");
		session.save(student);

		session.save(academic);
	}
	//getting student details by using usn
	@Transactional
	@Override
	public String getDetails(String usn) {
		StringBuffer strBuff = new StringBuffer(usn);
		String code1 = strBuff.substring(0, 3);
		Session session1 = this.sessionFactory.getCurrentSession();
		Query query = session1.createQuery("from College where code= :code");
		query.setParameter("code", code1);
		List listCol = query.list();
		Iterator itr = listCol.iterator();
		String place1 = null;
		while (itr.hasNext()) {
			College college = (College) itr.next();
			place1 = college.getPlace();
		}
		logger.info("Using usn from studentusn.jsp finding the place of student");
		System.out.println(place1);
		return place1;
	}
	//getting list of students based on page no
	public static List<Student> getAllStudents(int pageid, int total) {
		Object obj = null;
		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		String sql = "from Student";
		Query query = session.createQuery(sql);
		query.setFirstResult(pageid - 1);
		query.setMaxResults(total);
		List<Student> stddet = new ArrayList<Student>();
		List studlist = query.list();
		System.out.println("Displaying pagination contents");
		Iterator it = studlist.iterator();
		Student std = new Student();
		while (it.hasNext()) {
			std = (Student) it.next();
			System.out.println(std.getUsn() + "  " + std.getName() + "  " + std.getFatherName() + " " + std.getMotherName());
			stddet.add(std);
		}

		
		return stddet;

	}
	//getting student details using criteria
	@Transactional
	@Override
	public List<Student> studentList() {
		// TODO Auto-generated method stub
		Session session=this.sessionFactory.getCurrentSession();
		Criteria criteria=session.createCriteria(Student.class);
		
		List<Student> res=criteria.list();
		return res;
	}
	//method to get the students based on  whose age is greater than 21
	@Transactional
	@Override
	public List<Student> studentAge() {
		// TODO Auto-generated method stub
		Session session=this.sessionFactory.getCurrentSession();
		Criteria criteria=session.createCriteria(Student.class);
		criteria.add(Restrictions.gt("age", 21));
		
		List<Student> result=criteria.list();
		return result;
	}
	//listing the student details by using query 
	@Transactional
	@Override
	public List<Student> listStudent(int pageid,int total)
	{
		Session session=sessionFactory.getCurrentSession();
		try
		{
			Query query =session.createQuery("from student");
			query.setFirstResult(pageid-1);
			query.setMaxResults(total);
			System.out.println("hello");
			List<Student> stud=query.list();
			return stud;
		}
		catch(HibernateException e)
		{
			e.printStackTrace();
			session.getTransaction().rollback();
		}
		return null;
	}
}
